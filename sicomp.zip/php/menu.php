
      <header>
      	<div class="header-area" id="sticker">
      		<div class="container">
      			<div class="row">
      				<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
      					<!-- <div class="logo-area"><a href="index.php"><img src="img/logo.png" alt="image"></a></div> -->
      					<div class="logo-area"><a href="index.php"><img src="img/sicomp/logo.png"  style="height:110px;"alt="image"></a></div>
      				</div>
      				<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
						<div class="main-menu-area">
							<nav>
                    <ul id="nav">
                      <li class="active"><a href="./">Accueil</a>
                      </li> 
                      <li>
                        <a href="about.php">A propos de nous</a>
                      </li>
                      <li><a href="services.php">Nos Services</a></li>
                      <li class='has-submenu'>
                        <a href="#">Nos Equipements</a>
                        <ul>
                            <li><a href="equipements.php">Pésage</a></li>
                            <li><a href="equipements2.php">Détection</a></li>
                            <li><a href="equipements3.php">Geo-techniques</a></li>
                        </ul>
                      </li>
                      <li><a href="./#contactus">Contact</a></li>
                    </ul>
                  </nav>
						</div>
      		</div>
      			</div>
      		</div>
      	</div>
        <div class="mobile-menu-area">
            <div class="container">
              <div class="row">
                <div class="col-md-12">
                    <div class="mobile-menu">
                          <ul id="nav">
                            <li><a href="index.php">Home</a>
                            </li> 
                            <li>
                              <a href="about.php">A propos de nous</a>
                            </li>
                            <li><a href="services.php">Nos Services</a></li>
                            <li class='has-submenu'  class="active">
                              <a href="#">Nos Equipements</a>
                              <ul>
                                    <li><a href="equipements.php">Pésage</a></li>
                                    <li><a href="equipements2.php">Détection</a></li>
                                    <li><a href="equipements3.php">Geo-techniques</a></li>
                              </ul>
                            </li>
                            <li><a href="">Contact</a></li>
                          </ul>
                    </div>          
                </div>
              </div>
            </div>
        </div>
      </header>