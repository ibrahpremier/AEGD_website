<!doctype html>
<html class="no-js" lang="fr">
    <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Equipements | Sicomp</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- favicon
    ============================================ -->        
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">

    <!-- all css here -->
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- jquery-ui.min css -->
    <link rel="stylesheet" href="css/jquery-ui.min.css">
    <!-- nivo slider CSS
    ============================================ -->
    <link rel="stylesheet" href="lib/custom-slider/css/nivo-slider.css" type="text/css" />
    <link rel="stylesheet" href="lib/custom-slider/css/preview.css" type="text/css" media="screen" />
    <!-- meanmenu css -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- flaticon css -->
    <link rel="stylesheet" href="css/flaticon.css">
    <!-- style css -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- modernizr css -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body class="home-2">
      <!--[if lt IE 8]>
          <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- Add your site or application content here -->
      <!--  Header Area Start Here -->
         <?php include("php/menu.php") ?>
      <!-- Header Banner Area section Start Here -->
      <!-- Single Service Inner Section Start Here -->
      <div class="single-service-inner-page-area">
        <div class="container">
          <div class="row">
            <div class="single-service-inner-page">
              <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                <div class="single-service-inner-tab">    
                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs nav-tabs-equipement" role="tablist" >
                    <li role="presentation"><a href="equipements2.php">DETECTION </a></li>
                    <li role="presentation"><a href="equipements.php">PESAGE</a></li>
                    <li class="active" role="presentation"><a href="#0">GEOTECHNIQUES</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                <div class="single-service-inner-content">
                    <!-- Tab panes -->
                    <div class="tab-content">
                      <div role="tabpanel" class="tab-pane active" id="home">
                        <div class="single-service">
                          <h2>GEOTECHNIQUE</h2>
                          <p>
                            <h4>Nous vous fournissons  tous les équipements pour un laboratoire géotechnique. </h4> 
                            <em>images ci-dessous</em>
                          </p>
                          <div class="row">
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique1.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique2.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique3.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique4.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique5.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique6.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique7.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique8.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique9.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique10.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique11.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique12.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique13.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                            <div class="col-md-4">
                              <img src="img/sicomp/equipements/geotechnique14.jpg" alt="image equipement de pesage">
                              <h2>Masse Lorem</h2>
                              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus eligendi accusantium, dolores dolore quas impedit doloremque obcaecati inventore mollitia</p>
                            </div>
                          </div>

                        </div>
                      </div>
                    </div>        
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Single Service Inner Section End Here -->
      <!-- Footer Start Here -->
         <?php include("php/footer.php") ?>
      <!-- Footer End Here -->
  		<!-- all js here -->
  		<!-- jquery latest version -->
      <script src="js/vendor/jquery-1.12.0.min.js"></script>
  		<!-- bootstrap js -->
      <script src="js/bootstrap.min.js"></script>
  		<!-- owl.carousel js -->
      <script src="js/owl.carousel.min.js"></script>
      <!-- Nivo slider js --> 		
      <script src="lib/custom-slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
      <script src="lib/custom-slider/home.js" type="text/javascript"></script>
  		<!-- meanmenu js -->
      <script src="js/jquery.meanmenu.js"></script>
  		<!-- jquery-ui js -->
      <script src="js/jquery-ui.min.js"></script>
  		<!-- wow js -->
      <script src="js/wow.min.js"></script>
      <!-- jquery.scrollUp js -->
      <script src="js/jquery.scrollUp.min.js"></script>
  		<!-- plugins js -->
      <script src="js/plugins.js"></script>
      <!-- Cycle 2 slider js -->
      <script src="js/cycle2.js"></script>
      <script src="js/jquery.cycle2.carousel.js"></script>
      <!-- knob circle js -->
      <script src="js/jquery.knob.js"></script>
      <!-- jquery.appear js -->
      <script src="js/jquery.appear.js"></script> 
      <!-- Isotope js -->
      <script src="js/isotope.pkgd.js"></script>
  		<!-- main js -->
      <script src="js/main.js"></script>
    </body>
</html>